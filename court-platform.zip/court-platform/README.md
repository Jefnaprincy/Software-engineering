# AI-Powered Smart Court Case Management and Judicial Analytics Platform

A full-stack implementation covering all stated objectives:
- Digitized court case management (CRUD, role-based access)
- Automated legal document classification (keyword-weighted NLP-style classifier)
- Case completion timeline prediction (heuristic model using case type, priority, judge workload)
- Hearing scheduling with automatic conflict detection and slot suggestions
- Judicial workload analytics dashboard
- Legal analytics / reporting
- Instant precedent retrieval (relevance-ranked search)
- Automated sensitive-data (PII) redaction on document upload
- Secure role-based access: admin, judge, clerk, citizen

## Stack
- Frontend: React 18 + Vite, plain CSS (no external UI kit), Axios, React Router
- Backend: Node.js + Express, JWT auth, bcrypt password hashing
- Database: MySQL 8

## 1. Database setup
```bash
mysql -u root -p < database/schema.sql
```
This creates the `court_platform` database, all tables, and seeds sample legal precedents.

## 2. Backend setup
```bash
cd backend
npm install
cp .env.example .env
# edit .env: set DB_PASSWORD and a strong JWT_SECRET
npm run dev      # or: npm start
```
Backend runs on http://localhost:5000 (health check: GET /api/health).

## 3. Frontend setup
```bash
cd frontend
npm install
cp .env.example .env   # VITE_API_URL defaults to http://localhost:5000/api
npm run dev
```
Frontend runs on http://localhost:5173.

## 4. First use
1. Go to /register and create an **admin** account.
2. Create additional accounts with role **judge** and **clerk** (citizens can self-register).
3. Log in as clerk/admin → "File New Case" to create cases and assign a judge.
4. Use "Documents" to paste document text — it is auto-classified and PII-redacted.
5. Use "Hearings" to schedule — the system blocks double-booking and suggests a free slot.
6. "Analytics" shows live judicial workload and case-type/status/priority distributions.
7. "Precedents" lets you search the seeded case-law library by keyword.

## Notes on the "AI" components
This implementation uses transparent, dependency-free heuristics (keyword-weighted
classification, rule-based regex redaction, and a workload-adjusted duration model)
so the system runs immediately with no external AI/ML service or API key required.
The `backend/utils/` modules are isolated on purpose — swapping in a real NLP model
(e.g. a hosted LLM or a trained classifier) only requires replacing the internals of
`classifier.js`, `redactor.js`, and `predictor.js`; every route already calls them
through the same interface.

## Security notes for production
- JWT is stored in localStorage for simplicity — for production, prefer httpOnly cookies.
- Add rate limiting, input validation (e.g. Joi/Zod), and HTTPS termination.
- Rotate JWT_SECRET and never commit `.env` files.
